﻿namespace DemoLibrary {

    public struct Address {

        public int DoorNumber;
        public string StreetName;
        public string City;
        public string PostalCode;

    }

}