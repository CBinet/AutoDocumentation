﻿using AutoDocumentation;

namespace DemoLibrary {

    [AutoDocumentationIgnore]
    public struct IgnoredStruct {

        public string IgnoredText;
        public int IgnoredNumber;

    }

}