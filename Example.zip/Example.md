<h1>DemoLibrary</h1> <h2>Table Of Content :</h2><h3>Interfaces</h3>

+ <a href='#IFormattableAnchor'>IFormattable</a><br> 
<h3>Classes</h3>

+ <a href='#EmployeeAnchor'>Employee</a><br> 
<h3>Structures</h3>

+ <a href='#AddressAnchor'>Address</a><br> 
<h3>Enumerations</h3>

+ <a href='#DepartmentAnchor'>Department</a><br> 
<br> 
<hr> <h2 id='AddressAnchor'>DemoLibrary.Address : ValueType</h2> <h3>Fields : </h3><span style='font-family:consolas; font-size: 0.9em;'><font style='color:#ff80df;'><strong>public</strong> <strong></strong> <strong></strong> <strong>Int32</strong></font> DoorNumber</span><br> 
<span style='font-family:consolas; font-size: 0.9em;'><font style='color:#ff80df;'><strong>public</strong> <strong></strong> <strong></strong> <strong>String</strong></font> StreetName</span><br> 
<span style='font-family:consolas; font-size: 0.9em;'><font style='color:#ff80df;'><strong>public</strong> <strong></strong> <strong></strong> <strong>String</strong></font> City</span><br> 
<span style='font-family:consolas; font-size: 0.9em;'><font style='color:#ff80df;'><strong>public</strong> <strong></strong> <strong></strong> <strong>String</strong></font> PostalCode</span><br> 
  <h3>Methods : </h3><span style='font-family:consolas; font-size: 0.9em;'><font style='color:#ff80df;'><strong>public</strong> <strong></strong> <strong></strong> <strong>Boolean</strong></font> Equals(<strong>Object</strong> obj)</span><br> 
<span style='font-family:consolas; font-size: 0.9em;'><font style='color:#ff80df;'><strong>public</strong> <strong></strong> <strong></strong> <strong>Int32</strong></font> GetHashCode()</span><br> 
<span style='font-family:consolas; font-size: 0.9em;'><font style='color:#ff80df;'><strong>public</strong> <strong></strong> <strong></strong> <strong>String</strong></font> ToString()</span><br> 
<span style='font-family:consolas; font-size: 0.9em;'><font style='color:#ff80df;'><strong>public</strong> <strong></strong> <strong></strong> <strong>Type</strong></font> GetType()</span><br> 
<hr><h2 id='DepartmentAnchor'>DemoLibrary.Department</h2> <h4>Values : </h4>0 : <strong>Sales</strong>, <br> 
1 : <strong>Marketing</strong>, <br> 
2 : <strong>HumanResources</strong><br> 
<hr><h2 id='EmployeeAnchor'>DemoLibrary.Employee : <a href='#IFormattableAnchor'>IFormattable</a></h2> <h3>Fields : </h3><span style='font-family:consolas; font-size: 0.9em;'><font style='color:#ff80df;'><strong>public</strong> <strong></strong> <strong></strong> <strong>Int32</strong></font> Id</span><br> 
<span style='font-family:consolas; font-size: 0.9em;'><font style='color:#ff80df;'><strong>public</strong> <strong></strong> <strong></strong> <strong>String</strong></font> Name</span><br> 
<span style='font-family:consolas; font-size: 0.9em;'><font style='color:#ff80df;'><strong>public</strong> <strong></strong> <strong></strong> <strong>Address</strong></font> Address</span><br> 
<span style='font-family:consolas; font-size: 0.9em;'><font style='color:#ff80df;'><strong>public</strong> <strong></strong> <strong></strong> <strong>Department</strong></font> Department</span><br> 
 <h3>Constructors : </h3><span style='font-family:consolas; font-size: 0.9em;'><font style='color:#ff80df;'><strong>public</strong> <strong></strong></font> Employee(<strong>Int32</strong> pId, <strong>String</strong> pName, <strong><a href='#AddressAnchor'>Address</a></strong> address, <strong><a href='#DepartmentAnchor'>Department</a></strong> department)</span><br> 
 <h3>Methods : </h3><span style='font-family:consolas; font-size: 0.9em;'><font style='color:#ff80df;'><strong>public</strong> <strong></strong> <strong></strong> <strong>String</strong></font> FormatInformations()</span><br> 
<span style='font-family:consolas; font-size: 0.9em;'><font style='color:#ff80df;'><strong>public</strong> <strong></strong> <strong></strong> <strong>String</strong></font> ToString()</span><br> 
<span style='font-family:consolas; font-size: 0.9em;'><font style='color:#ff80df;'><strong>public</strong> <strong></strong> <strong></strong> <strong>Boolean</strong></font> Equals(<strong>Object</strong> obj)</span><br> 
<span style='font-family:consolas; font-size: 0.9em;'><font style='color:#ff80df;'><strong>public</strong> <strong></strong> <strong></strong> <strong>Int32</strong></font> GetHashCode()</span><br> 
<span style='font-family:consolas; font-size: 0.9em;'><font style='color:#ff80df;'><strong>public</strong> <strong></strong> <strong></strong> <strong>Type</strong></font> GetType()</span><br> 
<hr><h2 id='IFormattableAnchor'>DemoLibrary.IFormattable</h2>   <h3>Methods : </h3><span style='font-family:consolas; font-size: 0.9em;'><font style='color:#ff80df;'><strong>public</strong> <strong></strong> <strong>abstract</strong> <strong>String</strong></font> FormatInformations()</span><br> 
<hr>