﻿namespace DemoLibrary {

    internal class PrivateClass {

        public string PrivateText;
        public int PrivateNumber;

    }

}