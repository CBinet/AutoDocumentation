﻿namespace DemoLibrary {

    public enum Department {

        Sales,
        Marketing,
        HumanResources

    }

}