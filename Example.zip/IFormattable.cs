﻿namespace DemoLibrary {

    public interface IFormattable {

        string FormatInformations();

    }

}