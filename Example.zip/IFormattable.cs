﻿namespace DemoLibrary {

    public interface IFormattable {

        string GetFormattedInformations();

        void Format();

    }

}